#!/sbin/sh

uninstall_package() {
    ui_print "- Uninstalling $package_title"
    # Remove the files when we're uninstalling NiKGapps
    for i in $file_list; do
        uninstall_file "$i" "$package_name"
    done
    addon_index=10
    addon_file="$addon_index-$package_title.sh"
    # Removing the addon sh so it doesn't get backed up and restored
    addToLog "- Removing $addon_file"
    rm -rf "/system/addon.d/$addon_file"
    # Removing the updates and residue
    if [ -n "$2" ]; then
        for i in $(find /data -iname "*$2*" 2>/dev/null); do
            if [ -e "$i" ] || [ -d "$1"]; then
                addToLog "- contents matching $2 found at $i"
                rm -rf "$i"
            fi
        done
    fi
}

# Initialize the variables
clean_flash_only="false"
title="GoogleServicesFramework"
package_title="GoogleServicesFramework"
package_name="com.google.android.gsf"

file_list="
___priv-app___GoogleServicesFramework/GoogleServicesFramework.apk
___etc___permissions/com.google.android.gsf.xml
"

uninstall_package
