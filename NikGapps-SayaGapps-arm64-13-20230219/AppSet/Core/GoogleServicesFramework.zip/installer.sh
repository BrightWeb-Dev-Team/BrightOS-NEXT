#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"
install_partition="$3"

make_dir() {
  addToPackageLog "- Creating Directory: $install_partition/$1" "$package_title"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

get_prop_file_path() {
  propFilePath=""
  for i in $(find /system/etc/permissions -iname "$package_title.prop" 2>/dev/null;); do
    prop_file_path="$i"
    addToPackageLog "- Found prop file: $prop_file_path" "$package_title"
    break
  done
  addToPackageLog "- Prop file path before: $prop_file_path" "$package_title"
  [ -z "$prop_file_path" ] && prop_file_path="/system/etc/permissions/$package_title.prop"
  addToPackageLog "- Prop file path after: $prop_file_path" "$package_title"
  echo "$prop_file_path"
}
# Initialize the variables
default_partition="product"
clean_flash_only="false"
product_prefix=$(find_product_prefix "$install_partition")
title="GoogleServicesFramework"
package_title="GoogleServicesFramework"
pkg_size="7448"
package_name="com.google.android.gsf"
packagePath=installGoogleServicesFrameworkFiles
deleteFilesPath=deleteGoogleServicesFrameworkFiles
propFilePath=$(get_prop_file_path)

remove_aosp_apps_from_rom="
"

delete_overlays="
"

file_list="
___priv-app___GoogleServicesFramework/GoogleServicesFramework.apk
___etc___permissions/com.google.android.gsf.xml
"

remove_overlays() {
   for i in $delete_overlays; do
       delete_overlays "$i" "$propFilePath"
   done
}

remove_existing_package() {
   # remove the existing folder for clean install of GoogleServicesFramework
   delete_package "GoogleServicesFramework"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing GoogleServicesFramework
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i" "$propFilePath"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   remove_overlays
   # Create folders and set the permissions
   make_dir "priv-app/GoogleServicesFramework"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done

   chmod 755 "$COMMONDIR/addon";
   if [ -f "$propFilePath" ]; then
       echo "install=$(echo "$propFilePath" | sed "s|^$system/||")" >>"$TMPDIR/addon/$packagePath"
       addToPackageLog "- Adding $propFilePath to $TMPDIR/addon/$packagePath" "GoogleServicesFramework" 
   fi
   . $COMMONDIR/addon "$OFD" "GoogleServicesFramework" "$TMPDIR/addon/$packagePath" "$propFilePath" ""
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$propFilePath" "$logDir/addonfiles/$package_title.prop"
}

find_install_mode

